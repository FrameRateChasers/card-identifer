﻿Public Class Form1
    'JEFFREY HAGAN
    'VB FOR BUSINESS
    'CARD NAMES

    'varibles which represent cards
    Dim q As String = " This is Queen of Hearts"
    Dim h As String = " This is Eight of Hearts"
    Dim s As String = " This is Five of Spades"
    Dim c As String = " This is Six of Clubs"
    Dim d As String = " This is Eight of Diamonds"

    Private Sub picDiamond_Click(sender As Object, e As EventArgs) Handles picDiamond.Click
        lblOutput.Text = d
    End Sub

    Private Sub picQueen_Click(sender As Object, e As EventArgs) Handles picQueen.Click
        lblOutput.Text = q
    End Sub

    Private Sub picSpades_Click(sender As Object, e As EventArgs) Handles picSpades.Click
        lblOutput.Text = s
    End Sub

    Private Sub picClubs_Click(sender As Object, e As EventArgs) Handles picClubs.Click
        lblOutput.Text = c
    End Sub

    Private Sub picHeart_Click(sender As Object, e As EventArgs) Handles picHeart.Click
        lblOutput.Text = h
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
