﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.picClubs = New System.Windows.Forms.PictureBox()
        Me.picSpades = New System.Windows.Forms.PictureBox()
        Me.picDiamond = New System.Windows.Forms.PictureBox()
        Me.picQueen = New System.Windows.Forms.PictureBox()
        Me.picHeart = New System.Windows.Forms.PictureBox()
        CType(Me.picClubs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSpades, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picDiamond, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picQueen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picHeart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(236, 392)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(155, 83)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblOutput
        '
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutput.Location = New System.Drawing.Point(95, 316)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(443, 49)
        Me.lblOutput.TabIndex = 1
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(95, 23)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(443, 39)
        Me.lblTitle.TabIndex = 2
        Me.lblTitle.Text = "Click a card to see its name"
        '
        'picClubs
        '
        Me.picClubs.Image = CType(resources.GetObject("picClubs.Image"), System.Drawing.Image)
        Me.picClubs.Location = New System.Drawing.Point(144, 98)
        Me.picClubs.Name = "picClubs"
        Me.picClubs.Size = New System.Drawing.Size(101, 188)
        Me.picClubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picClubs.TabIndex = 4
        Me.picClubs.TabStop = False
        '
        'picSpades
        '
        Me.picSpades.Image = CType(resources.GetObject("picSpades.Image"), System.Drawing.Image)
        Me.picSpades.Location = New System.Drawing.Point(262, 98)
        Me.picSpades.Name = "picSpades"
        Me.picSpades.Size = New System.Drawing.Size(101, 188)
        Me.picSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSpades.TabIndex = 5
        Me.picSpades.TabStop = False
        '
        'picDiamond
        '
        Me.picDiamond.Image = CType(resources.GetObject("picDiamond.Image"), System.Drawing.Image)
        Me.picDiamond.Location = New System.Drawing.Point(384, 98)
        Me.picDiamond.Name = "picDiamond"
        Me.picDiamond.Size = New System.Drawing.Size(101, 188)
        Me.picDiamond.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picDiamond.TabIndex = 6
        Me.picDiamond.TabStop = False
        '
        'picQueen
        '
        Me.picQueen.Image = CType(resources.GetObject("picQueen.Image"), System.Drawing.Image)
        Me.picQueen.Location = New System.Drawing.Point(501, 98)
        Me.picQueen.Name = "picQueen"
        Me.picQueen.Size = New System.Drawing.Size(109, 188)
        Me.picQueen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picQueen.TabIndex = 7
        Me.picQueen.TabStop = False
        '
        'picHeart
        '
        Me.picHeart.Image = CType(resources.GetObject("picHeart.Image"), System.Drawing.Image)
        Me.picHeart.Location = New System.Drawing.Point(16, 98)
        Me.picHeart.Name = "picHeart"
        Me.picHeart.Size = New System.Drawing.Size(111, 188)
        Me.picHeart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picHeart.TabIndex = 3
        Me.picHeart.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(638, 487)
        Me.Controls.Add(Me.picQueen)
        Me.Controls.Add(Me.picDiamond)
        Me.Controls.Add(Me.picSpades)
        Me.Controls.Add(Me.picClubs)
        Me.Controls.Add(Me.picHeart)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.btnExit)
        Me.DoubleBuffered = True
        Me.Name = "Form1"
        Me.Text = "Card Identifer"
        CType(Me.picClubs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSpades, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picDiamond, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picQueen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picHeart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents lblOutput As Label
    Friend WithEvents lblTitle As Label
    Friend WithEvents picClubs As PictureBox
    Friend WithEvents picSpades As PictureBox
    Friend WithEvents picDiamond As PictureBox
    Friend WithEvents picQueen As PictureBox
    Friend WithEvents picHeart As PictureBox
End Class
